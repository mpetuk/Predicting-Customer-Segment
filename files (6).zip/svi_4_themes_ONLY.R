library(leaflet)
library(tigris)
library(sf)
library(dplyr)
library(htmltools)

# =============================================================================
# SVI LEAFLET MAP - 4 THEME LAYERS ONLY (NO OVERALL SVI)
# Based on meeting notes 2/19 - Sequential color schemes for each theme
# =============================================================================

# File path to SVI data
SVI_CSV_PATH <- "/mnt/user-data/uploads/SVI_2022_US_ZCTA.csv"

# Color schemes for 4 RPL themes (NO Overall SVI layer)
color_scheme_theme1 <- c("#1A9850", "#91CF60", "#D9EF8B", "#FFFFBF")   # Green (Socioeconomic)
color_scheme_theme2 <- c("#D95F0E", "#FEC44F", "#FEE391", "#FFFFD4")   # Orange (Household)
color_scheme_theme3 <- c("#54278F", "#9E9AC8", "#DADAEB", "#F2F0F7")   # Purple (Minority)
color_scheme_theme4 <- c("#08519C", "#6BAED6", "#BDD7E7", "#EFF3FF")   # Blue (Housing/Transport)

# Percentile breaks (CDC standard)
breaks <- c(0, 0.50, 0.75, 0.90, 1.0)

# =============================================================================
# LOAD DATA
# =============================================================================

cat("Loading SVI data...\n")
svi_data <- read.csv(SVI_CSV_PATH, stringsAsFactors = FALSE)

# Filter: Remove ZCTAs with no population or missing data
svi_data <- svi_data %>%
  filter(E_TOTPOP > 0, RPL_THEME1 != -999)

cat(sprintf("Loaded %d valid ZCTAs\n", nrow(svi_data)))

# =============================================================================
# GET ZCTA BOUNDARIES
# =============================================================================

cat("Downloading ZCTA boundaries...\n")
zcta_boundaries <- zctas(year = 2022, cb = TRUE)

# Join SVI data to boundaries
cat("Joining SVI data to boundaries...\n")
zcta_map_data <- zcta_boundaries %>%
  left_join(svi_data, by = c("GEOID20" = "GEOID")) %>%
  filter(!is.na(RPL_THEME1))

cat(sprintf("Final map dataset: %d ZCTAs\n", nrow(zcta_map_data)))

# =============================================================================
# CREATE COLOR PALETTES (4 THEMES ONLY)
# =============================================================================

pal_theme1 <- colorBin(
  palette = color_scheme_theme1,
  domain = zcta_map_data$RPL_THEME1,
  bins = breaks,
  na.color = "#808080"
)

pal_theme2 <- colorBin(
  palette = color_scheme_theme2,
  domain = zcta_map_data$RPL_THEME2,
  bins = breaks,
  na.color = "#808080"
)

pal_theme3 <- colorBin(
  palette = color_scheme_theme3,
  domain = zcta_map_data$RPL_THEME3,
  bins = breaks,
  na.color = "#808080"
)

pal_theme4 <- colorBin(
  palette = color_scheme_theme4,
  domain = zcta_map_data$RPL_THEME4,
  bins = breaks,
  na.color = "#808080"
)

# =============================================================================
# CREATE POPUP CONTENT
# =============================================================================

create_popup <- function(data, theme_name, rpl_value) {
  paste0(
    "<strong>ZCTA: </strong>", data$GEOID20, "<br>",
    "<strong>Population: </strong>", formatC(data$E_TOTPOP, format = "d", big.mark = ","), "<br>",
    "<strong>", theme_name, ": </strong>", 
    ifelse(is.na(rpl_value), "No data", sprintf("%.3f", rpl_value)), "<br>",
    "<strong>Percentile: </strong>",
    case_when(
      is.na(rpl_value) ~ "N/A",
      rpl_value >= 0.90 ~ "≥90th (Highest vulnerability)",
      rpl_value >= 0.75 ~ "75-89th (High vulnerability)",
      rpl_value >= 0.50 ~ "50-74th (Moderate vulnerability)",
      TRUE ~ "<50th (Lower vulnerability)"
    )
  )
}

# =============================================================================
# CREATE LEAFLET MAP - 4 THEME LAYERS ONLY
# =============================================================================

cat("Creating Leaflet map with 4 theme layers...\n")

map <- leaflet(zcta_map_data) %>%
  addProviderTiles(providers$CartoDB.Positron) %>%
  setView(lng = -98.5795, lat = 39.8283, zoom = 4) %>%
  
  # ==========================================================================
  # LAYER 1: Theme 1 - Socioeconomic Status (Green)
  # ==========================================================================
  addPolygons(
    fillColor = ~pal_theme1(RPL_THEME1),
    fillOpacity = 0.7,
    color = "#FFFFFF",
    weight = 1,
    popup = ~create_popup(zcta_map_data, "Socioeconomic Status", RPL_THEME1),
    group = "SVI - Socioeconomic",
    highlightOptions = highlightOptions(
      weight = 2,
      color = "#666",
      fillOpacity = 0.9,
      bringToFront = TRUE
    )
  ) %>%
  
  # ==========================================================================
  # LAYER 2: Theme 2 - Household Composition (Orange)
  # ==========================================================================
  addPolygons(
    fillColor = ~pal_theme2(RPL_THEME2),
    fillOpacity = 0.7,
    color = "#FFFFFF",
    weight = 1,
    popup = ~create_popup(zcta_map_data, "Household Characteristics", RPL_THEME2),
    group = "SVI - Household",
    highlightOptions = highlightOptions(
      weight = 2,
      color = "#666",
      fillOpacity = 0.9,
      bringToFront = TRUE
    )
  ) %>%
  
  # ==========================================================================
  # LAYER 3: Theme 3 - Racial/Ethnic Minority (Purple)
  # ==========================================================================
  addPolygons(
    fillColor = ~pal_theme3(RPL_THEME3),
    fillOpacity = 0.7,
    color = "#FFFFFF",
    weight = 1,
    popup = ~create_popup(zcta_map_data, "Racial/Ethnic Minority Status", RPL_THEME3),
    group = "SVI - Racial/Ethnic",
    highlightOptions = highlightOptions(
      weight = 2,
      color = "#666",
      fillOpacity = 0.9,
      bringToFront = TRUE
    )
  ) %>%
  
  # ==========================================================================
  # LAYER 4: Theme 4 - Housing & Transportation (Blue)
  # ==========================================================================
  addPolygons(
    fillColor = ~pal_theme4(RPL_THEME4),
    fillOpacity = 0.7,
    color = "#FFFFFF",
    weight = 1,
    popup = ~create_popup(zcta_map_data, "Housing & Transportation", RPL_THEME4),
    group = "SVI - Housing/Transport",
    highlightOptions = highlightOptions(
      weight = 2,
      color = "#666",
      fillOpacity = 0.9,
      bringToFront = TRUE
    )
  ) %>%
  
  # ==========================================================================
  # LAYER CONTROLS - 4 THEMES ONLY
  # ==========================================================================
  addLayersControl(
    baseGroups = c(
      "SVI - Socioeconomic",
      "SVI - Household",
      "SVI - Racial/Ethnic",
      "SVI - Housing/Transport"
    ),
    options = layersControlOptions(collapsed = FALSE)
  ) %>%
  
  # ==========================================================================
  # LEGENDS - ONE FOR EACH THEME
  # ==========================================================================
  addLegend(
    position = "bottomright",
    pal = pal_theme1,
    values = ~RPL_THEME1,
    title = "Socioeconomic<br>Percentile",
    opacity = 0.7,
    group = "SVI - Socioeconomic"
  ) %>%
  
  addLegend(
    position = "bottomright",
    pal = pal_theme2,
    values = ~RPL_THEME2,
    title = "Household<br>Percentile",
    opacity = 0.7,
    group = "SVI - Household"
  ) %>%
  
  addLegend(
    position = "bottomright",
    pal = pal_theme3,
    values = ~RPL_THEME3,
    title = "Racial/Ethnic<br>Percentile",
    opacity = 0.7,
    group = "SVI - Racial/Ethnic"
  ) %>%
  
  addLegend(
    position = "bottomright",
    pal = pal_theme4,
    values = ~RPL_THEME4,
    title = "Housing/Transport<br>Percentile",
    opacity = 0.7,
    group = "SVI - Housing/Transport"
  )

# Save map
cat("Saving map to HTML...\n")
library(htmlwidgets)
saveWidget(map, "/mnt/user-data/outputs/svi_4_themes_only.html", selfcontained = TRUE)

cat("\n")
cat("="*80, "\n")
cat("✓ Map created successfully!\n")
cat("✓ 4 SVI THEME LAYERS ONLY (NO Overall SVI)\n")
cat("✓ Layers: Socioeconomic, Household, Racial/Ethnic, Housing/Transport\n")
cat("✓ Colors: Green, Orange, Purple, Blue\n")
cat("\n")
cat("Open: /mnt/user-data/outputs/svi_4_themes_only.html\n")
cat("="*80, "\n")

# Return map
map
